import {
  doc,
  getDoc,
  updateDoc,
} from 'firebase/firestore';

import { db } from './config';

export const completeModule = async (
  uid: string,
  moduleName: string,
  quizScore?: number
) => {
  try {
    const userRef = doc(db, 'users', uid);

    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) {
      return {
        success: false,
        error: 'User not found',
      };
    }

    const userData = userSnap.data();

    // Existing progress
    const progress = userData.progress || {};
    progress[moduleName] = true;

    // Analytics field
    const completedModules =
      userData.completedModules || {};

    completedModules[moduleName] = true;

    // Quiz scores
    const quizScores =
      userData.quizScores || {};

    if (quizScore !== undefined) {
      quizScores[moduleName] = quizScore;
    }

    await updateDoc(userRef, {
      progress,
      completedModules,
      quizScores,
    });

    return {
      success: true,
      progress,
      completedModules,
      quizScores,
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message,
    };
  }
};