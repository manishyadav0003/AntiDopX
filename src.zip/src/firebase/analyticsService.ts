import {
  doc,
  getDoc,
} from 'firebase/firestore';

import { db } from './config';

export type AnalyticsData = {
  knowledgeGrowth: number;
  quizAccuracy: number;
  completedModules: number;
  totalModules: number;
  streak: number;

  monthlyXP: {
    w1: number;
    w2: number;
    w3: number;
    w4: number;
    w5: number;
    w6: number;
    w7: number;
  };

  moduleCompletion: {
    title: string;
    progress: number;
  }[];

  weakArea: {
    title: string;
    score: number;
  };
};

export const getAnalytics = async (
  uid: string
) => {
  try {
    const userRef = doc(db, 'users', uid);

    const snap = await getDoc(userRef);

    if (!snap.exists()) {
      return {
        success: false,
        error: 'User not found',
      };
    }

    const data = snap.data();

    const quizScores = data.quizScores || {};

    const completedModules =
      Object.values(data.completedModules || {})
        .filter(Boolean).length;

    const totalModules = 6;

    const scoreValues = Object.values(
      quizScores
    ) as number[];

    const averageScore =
      scoreValues.length > 0
        ? scoreValues.reduce(
            (a, b) => a + b,
            0
          ) / scoreValues.length
        : 0;

    const moduleCompletion = [
      {
        title: 'Basics',
        progress:
          quizScores.antiDopingBasics || 0,
      },
      {
        title: 'Substances',
        progress:
          quizScores.wadaRules || 0,
      },
      {
        title: 'Testing',
        progress:
          quizScores.testingProcedures ||
          0,
      },
      {
        title: 'TUE',
        progress:
          quizScores.tue || 0,
      },
      {
        title: 'Supplements',
        progress:
          quizScores.supplements || 0,
      },
      {
        title: 'Ethics',
        progress:
          quizScores.ethics || 0,
      },
    ];

    const weakest =
      moduleCompletion.reduce(
        (lowest, current) =>
          current.progress <
          lowest.progress
            ? current
            : lowest
      );

    return {
      success: true,
      data: {
        knowledgeGrowth: Math.round(
          (completedModules /
            totalModules) *
            100
        ),

        quizAccuracy:
          Math.round(averageScore),

        completedModules,

        totalModules,

        streak: data.streak || 0,

        monthlyXP:
          data.monthlyXP || {
            w1: 0,
            w2: 0,
            w3: 0,
            w4: 0,
            w5: 0,
            w6: 0,
            w7: 0,
          },

        moduleCompletion,

        weakArea: weakest,
      } as AnalyticsData,
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message,
    };
  }
};