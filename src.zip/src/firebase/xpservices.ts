import {
  doc,
  getDoc,
  updateDoc,
} from 'firebase/firestore';

import { db } from './config';

const calculateLevel = (xp: number) => {
  if (xp >= 1000) return 'Elite Athlete';
  if (xp >= 300) return 'Champion';
  if (xp >= 100) return 'Competitor';
  return 'Rookie';
};

const getCurrentWeek = () => {
  const today = new Date();

  const day = today.getDate();

  if (day <= 7) return 'w1';
  if (day <= 14) return 'w2';
  if (day <= 21) return 'w3';
  if (day <= 28) return 'w4';

  return 'w5';
};

export const addXP = async (
  uid: string,
  amount: number
) => {
  try {
    const userRef = doc(db, 'users', uid);

    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) {
      return {
        success: false,
        error: 'User not found',
      };
    }

    const userData = userSnap.data();

    const currentXP = userData.xp || 0;

    const newXP = currentXP + amount;

    const newLevel = calculateLevel(newXP);

    const monthlyXP = userData.monthlyXP || {
      w1: 0,
      w2: 0,
      w3: 0,
      w4: 0,
      w5: 0,
    };

    const currentWeek = getCurrentWeek();

    monthlyXP[currentWeek] =
      (monthlyXP[currentWeek] || 0) + amount;

    await updateDoc(userRef, {
      xp: newXP,
      level: newLevel,
      monthlyXP,
    });

    return {
      success: true,
      xp: newXP,
      level: newLevel,
      monthlyXP,
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message,
    };
  }
};